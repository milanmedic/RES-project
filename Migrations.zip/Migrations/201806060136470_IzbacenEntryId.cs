namespace Common.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class IzbacenEntryId : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("dbo.Entries");
            AlterColumn("dbo.Entries", "Hour", c => c.String(nullable: false, maxLength: 128));
            AddPrimaryKey("dbo.Entries", "Hour");
            DropColumn("dbo.Entries", "Id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Entries", "Id", c => c.Int(nullable: false, identity: true));
            DropPrimaryKey("dbo.Entries");
            AlterColumn("dbo.Entries", "Hour", c => c.String());
            AddPrimaryKey("dbo.Entries", "Id");
        }
    }
}
