namespace Common.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UIntPoljePotrosnje : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Entries", "Consumption", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Entries", "Consumption", c => c.Int(nullable:false));
        }
    }
}
