namespace Common.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class StaroIntPolje : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Entries", "Consumption", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Entries", "Consumption");
        }
    }
}
