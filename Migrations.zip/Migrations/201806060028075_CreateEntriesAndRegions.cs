namespace Common.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CreateEntriesAndRegions : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Entries",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Hour = c.String(nullable: false),
                        Consumption = c.Int(nullable: false),
                        Area = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            //CreateTable(
            //    "dbo.Regions",
            //    c => new
            //        {
            //            Id = c.String(nullable: false, maxLength: 128),
            //            Naziv = c.String(nullable: false),
            //        })
            //    .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            //DropTable("dbo.Regions");
            DropTable("dbo.Entries");
        }
    }
}
