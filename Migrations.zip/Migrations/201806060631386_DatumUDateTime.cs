namespace Common.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DatumUDateTime : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Entries", "Datum", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Entries", "Datum", c => c.String());
        }
    }
}
